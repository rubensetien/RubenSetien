public class RegularUser extends User{
}
